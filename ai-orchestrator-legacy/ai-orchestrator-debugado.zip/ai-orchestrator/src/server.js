import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

async function loadEnv(file) {
  try {
    const text = await fs.readFile(file, 'utf8');
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith('#')) continue;
      const idx = line.indexOf('=');
      if (idx < 1) continue;
      const key = line.slice(0, idx).trim();
      const value = line.slice(idx + 1).trim();
      if (!(key in process.env)) process.env[key] = value;
    }
  } catch {}
}
await loadEnv(path.join(root, '.env'));

const { getProviders, getProvider } = await import('./providers/registry.js');
const { chat, getCircuitState } = await import('./orchestrator/engine.js');
const { diagnostics, runDevTool } = await import('./devtools/index.js');

const host = process.env.APP_HOST || '127.0.0.1';
const port = Number(process.env.APP_PORT || 3000);
const publicRoot = path.resolve(root, 'public');

const mime = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon'
};

async function sendStatic(res, urlPath) {
  const safe = urlPath === '/' ? '/index.html' : urlPath;
  const target = path.resolve(publicRoot, `.${safe}`);
  if (!target.startsWith(publicRoot + path.sep)) return false;
  try {
    const stat = await fs.stat(target);
    if (!stat.isFile()) return false;
    res.writeHead(200, { 'Content-Type': mime[path.extname(target)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(await fs.readFile(target));
    return true;
  } catch { return false; }
}

async function readJson(req) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (body.length > 3_000_000) throw new Error('Payload muito grande.');
  }
  try { return JSON.parse(body || '{}'); }
  catch { const error = new Error('JSON inválido.'); error.status = 400; throw error; }
}

function sendJson(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || host}`);
    if (req.method === 'GET' && url.pathname === '/api/health') {
      return sendJson(res, 200, { ok: true, time: new Date().toISOString(), version: '0.5.1' });
    }
    if (req.method === 'GET' && url.pathname === '/api/providers') return sendJson(res, 200, getProviders());
    if (req.method === 'GET' && url.pathname === '/api/status') return sendJson(res, 200, { providers: getProviders(), circuits: getCircuitState(), tools: await diagnostics() });
    if (req.method === 'GET' && url.pathname.startsWith('/api/providers/')) {
      try { return sendJson(res, 200, getProvider(url.pathname.split('/').pop())); }
      catch (e) { return sendJson(res, 404, { error: e.message }); }
    }
    if (req.method === 'GET' && url.pathname === '/api/dev-tools') return sendJson(res, 200, await diagnostics());
    if (req.method === 'POST' && url.pathname === '/api/dev-tools/run') {
      const body = await readJson(req);
      const tool = String(body.tool || '');
      if (!tool) { const error = new Error('Ferramenta não informada.'); error.status = 400; throw error; }
      return sendJson(res, 200, await runDevTool(tool));
    }
    if (req.method === 'POST' && url.pathname === '/api/chat') {
      const body = await readJson(req);
      const result = await chat(body);
      return sendJson(res, 200, result);
    }
    if (req.method === 'GET') {
      if (await sendStatic(res, url.pathname)) return;
      if (await sendStatic(res, '/index.html')) return;
    }
    return sendJson(res, 404, { error: 'Not found' });
  } catch (error) {
    return sendJson(res, Number(error.status) || 500, { error: error.message || 'Internal server error' });
  }
});

server.listen(port, host, () => console.log(`AI Orchestrator: http://${host}:${port}`));
