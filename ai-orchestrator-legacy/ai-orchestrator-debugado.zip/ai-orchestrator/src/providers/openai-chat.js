export async function callOpenAIChat(provider, { model, messages, temperature = 0.4, maxTokens = 4096 }) {
  const url = `${provider.baseUrl}/chat/completions`;
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env[provider.envKey]}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: model || provider.defaultModel,
      messages,
      temperature,
      max_tokens: maxTokens,
      stream: false
    })
  });

  const raw = await response.text();
  let data;
  try { data = JSON.parse(raw); } catch { data = { raw }; }

  if (!response.ok) {
    const error = new Error(data?.error?.message || data?.message || `Provider returned HTTP ${response.status}`);
    error.status = response.status;
    error.providerPayload = data;
    throw error;
  }

  return {
    provider: provider.id,
    model: model || provider.defaultModel,
    text: data?.choices?.[0]?.message?.content ?? '',
    usage: data?.usage ?? null,
    raw: data
  };
}
