import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const configPath = path.resolve(__dirname, '../../config/providers.json');
const config = JSON.parse(await fs.readFile(configPath, 'utf8'));

function normalize(id, p) {
  return {
    id,
    ...p,
    configured: Boolean(process.env[p.envKey]),
    priority: Number.isFinite(p.priority) ? p.priority : 100,
    capabilities: p.capabilities || { text: true, vision: false, tools: false, streaming: Boolean(p.supportsStreaming) }
  };
}

export function getProviders() {
  return Object.entries(config).map(([id, p]) => normalize(id, p));
}

export function getProvider(id) {
  const provider = config[id];
  if (!provider) throw new Error(`Unknown provider: ${id}`);
  return normalize(id, provider);
}

export function eligibleProviders({ freeOnly = false, capability = null } = {}) {
  return getProviders().filter(p => {
    if (!p.configured) return false;
    if (freeOnly && !p.freePool) return false;
    if (capability && !p.capabilities?.[capability]) return false;
    return true;
  });
}

export function getConfiguredProviderSummary() {
  return getProviders().map(({ id, name, configured, defaultModel, freePool, priority, capabilities }) => ({
    id, name, configured, defaultModel, freePool, priority, capabilities
  }));
}
