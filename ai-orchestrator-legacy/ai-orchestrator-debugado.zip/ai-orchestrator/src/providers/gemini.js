export async function callGemini(provider, { model, messages, temperature = 0.4, maxTokens = 4096 }) {
  const selectedModel = model || provider.defaultModel;
  const url = `${provider.baseUrl}/models/${encodeURIComponent(selectedModel)}:generateContent?key=${encodeURIComponent(process.env[provider.envKey])}`;

  const systemParts = [];
  const contents = [];
  for (const message of messages) {
    if (message.role === 'system') {
      systemParts.push({ text: message.content });
    } else {
      contents.push({
        role: message.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: message.content }]
      });
    }
  }

  const body = {
    ...(systemParts.length ? { systemInstruction: { parts: systemParts } } : {}),
    contents,
    generationConfig: {
      temperature,
      maxOutputTokens: maxTokens
    }
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  const raw = await response.text();
  let data;
  try { data = JSON.parse(raw); } catch { data = { raw }; }

  if (!response.ok) {
    const error = new Error(data?.error?.message || `Google AI returned HTTP ${response.status}`);
    error.status = response.status;
    error.providerPayload = data;
    throw error;
  }

  const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
  return { provider: provider.id, model: selectedModel, text, usage: data?.usageMetadata || null, raw: data };
}
