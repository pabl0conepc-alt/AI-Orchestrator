import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';

const execFileAsync = promisify(execFile);
const root = path.resolve(process.cwd());

const COMMANDS = {
  node: ['node', ['--version']],
  npm: ['npm', ['--version']],
  git: ['git', ['--version']],
  rg: ['rg', ['--version']],
  python: ['python3', ['--version']]
};

async function exists(command, args) {
  try {
    const { stdout, stderr } = await execFileAsync(command, args, { cwd: root, timeout: 5000, windowsHide: true });
    return { installed: true, version: (stdout || stderr).split(/\r?\n/)[0].trim() };
  } catch {
    return { installed: false, version: null };
  }
}

export async function diagnostics() {
  const tools = {};
  for (const [name, [cmd, args]] of Object.entries(COMMANDS)) tools[name] = await exists(cmd, args);
  let packageJson = null;
  try { packageJson = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8')); } catch {}
  return {
    platform: `${os.platform()} ${os.arch()}`,
    cwd: root,
    node: tools.node,
    tools,
    packageScripts: packageJson?.scripts || {}
  };
}

const ALLOWED = {
  'git-status': ['git', ['status', '--short', '--branch']],
  'git-diff': ['git', ['diff', '--stat']],
  'npm-test': ['npm', ['test']],
  'npm-check': ['npm', ['run', 'check']],
  'npm-build': ['npm', ['run', 'build']]
};

export async function runDevTool(tool) {
  const entry = ALLOWED[tool];
  if (!entry) throw new Error(`Ferramenta não permitida: ${tool}`);
  const [cmd, args] = entry;
  try {
    const result = await execFileAsync(cmd, args, { cwd: root, timeout: 120000, windowsHide: true, maxBuffer: 2_000_000 });
    return { tool, ok: true, stdout: result.stdout || '', stderr: result.stderr || '' };
  } catch (error) {
    return { tool, ok: false, code: error.code ?? 1, stdout: error.stdout || '', stderr: error.stderr || error.message || '' };
  }
}
