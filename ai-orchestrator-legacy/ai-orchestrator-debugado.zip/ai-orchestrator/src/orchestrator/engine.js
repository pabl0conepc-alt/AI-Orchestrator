import { getProvider, eligibleProviders } from '../providers/registry.js';
import { callOpenAIChat } from '../providers/openai-chat.js';
import { callGemini } from '../providers/gemini.js';
import { callOpenCode } from '../providers/opencode.js';
import { compactMessages, shouldFallback, resolveModel, rankProviders, backoffMs } from './policy.js';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const systemPrompt = await fs.readFile(path.resolve(__dirname, '../../prompts/coding-system.md'), 'utf8');
const breaker = new Map();

function now() { return Date.now(); }

function withSystem(messages, { coding = true, profile = 'coding' } = {}) {
  const profilePrompt = profile === 'general'
    ? 'You are a helpful general-purpose assistant. Be accurate, practical, transparent about uncertainty, and concise.'
    : systemPrompt;
  return [{ role: 'system', content: coding ? profilePrompt : 'You are a helpful AI assistant. Be accurate, practical, and concise.' }, ...messages.filter(m => m.role !== 'system')];
}

function isOpen(providerId) {
  const state = breaker.get(providerId);
  if (!state) return true;
  if (state.openUntil <= now()) return true;
  return false;
}

function registerSuccess(providerId) { breaker.delete(providerId); }

function registerFailure(providerId) {
  const previous = breaker.get(providerId) || { failures: 0, openUntil: 0 };
  const failures = previous.failures + 1;
  const threshold = Number(process.env.CIRCUIT_FAILURE_THRESHOLD || 3);
  const cooldown = Number(process.env.CIRCUIT_COOLDOWN_MS || 30000);
  breaker.set(providerId, { failures, openUntil: failures >= threshold ? now() + cooldown : 0 });
}

async function callProvider(provider, payload) {
  if (!provider?.configured) throw new Error(`Provider ${provider?.id || 'unknown'} is not configured.`);
  if (!isOpen(provider.id)) {
    const error = new Error(`Provider ${provider.id} is temporarily paused after repeated failures.`);
    error.status = 503;
    throw error;
  }
  try {
    const result = provider.transport === 'gemini'
      ? await callGemini(provider, payload)
      : provider.transport === 'opencode-responses'
        ? await callOpenCode(provider, payload)
        : await callOpenAIChat(provider, payload);
    registerSuccess(provider.id);
    return result;
  } catch (error) {
    registerFailure(provider.id);
    throw error;
  }
}

async function callWithRetry(provider, payload, { retries = 2 } = {}) {
  const attempts = Math.max(1, Number(retries) || 1);
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await callProvider(provider, payload);
    } catch (error) {
      lastError = error;
      if (!shouldFallback(error) || attempt === attempts) break;
      await new Promise(resolve => setTimeout(resolve, backoffMs(attempt)));
    }
  }
  throw lastError;
}

function defaultPool() {
  return rankProviders(eligibleProviders({ freeOnly: false }), { preferFree: process.env.PREFER_FREE_PROVIDERS !== 'false' });
}

function sanitizeAgents(selectedProviders) {
  const pool = Array.isArray(selectedProviders) ? selectedProviders : [];
  return pool.map(id => {
    try { return getProvider(id); } catch { return null; }
  }).filter(p => p?.configured);
}

const AGENT_ROLES = [
  { id: 'architect', name: 'Arquiteto', instruction: 'Defina arquitetura, módulos, contratos, dependências e riscos. Não escreva a solução inteira; entregue um plano implementável.' },
  { id: 'implementer', name: 'Implementador', instruction: 'Concentre-se em código concreto, estrutura de arquivos, APIs, interfaces e implementação incremental. Aponte decisões técnicas.' },
  { id: 'reviewer', name: 'Revisor', instruction: 'Procure bugs, incompatibilidades, problemas de manutenção, testes ausentes e regressões. Proponha correções precisas.' },
  { id: 'security', name: 'Segurança', instruction: 'Analise segredos, validação, autenticação, permissões, injeção, dependências e exposição de dados. Sugira mitigação prática.' },
  { id: 'tester', name: 'Testador', instruction: 'Crie uma estratégia de testes, casos extremos, verificações automatizadas e critérios objetivos para considerar a tarefa concluída.' }
];

function roleFor(index) { return AGENT_ROLES[index % AGENT_ROLES.length]; }

async function runMultiAgent({ providers, prepared, latestUser, model, temperature, maxTokens }) {
  const agentResults = await Promise.allSettled(providers.map(async (provider, index) => {
    const role = roleFor(index);
    const agentMessages = [
      ...prepared,
      {
        role: 'user',
        content: `Você é o agente ${role.name}.\n\nMISSÃO ESPECIALIZADA:\n${role.instruction}\n\nPEDIDO DO USUÁRIO:\n${latestUser}`
      }
    ];
    const agentModel = resolveModel(provider, index === 0 && model ? model : undefined);
    return callWithRetry(provider, { model: agentModel, messages: agentMessages, temperature, maxTokens }, { retries: 2 });
  }));

  const successful = agentResults
    .filter(x => x.status === 'fulfilled')
    .map(x => x.value);
  if (!successful.length) {
    const failures = agentResults.filter(x => x.status === 'rejected').map(x => x.reason?.message).filter(Boolean);
    throw new Error(`Todos os agentes falharam. ${failures.join(' | ')}`);
  }

  const coordinatorPool = rankProviders(eligibleProviders({ freeOnly: false }), { preferFree: true });
  const dossier = successful.map((x, i) => `AGENTE ${i + 1} [${x.provider}/${x.model}]\n${x.text}`).join('\n\n---\n\n');
  const synthesisPrompt = `${latestUser}\n\nANÁLISES DOS AGENTES:\n${dossier}\n\nVocê é o COORDENADOR FINAL. Compare as análises, elimine contradições, corrija erros óbvios e entregue uma única resposta pronta para uso. Para tarefas de código, prefira arquivos completos, passos de execução e testes. Não mencione que você recebeu relatórios internos.`;

  let lastError;
  for (const provider of coordinatorPool) {
    try {
      const result = await callWithRetry(provider, {
        model: resolveModel(provider, provider.id === providers[0].id ? model : undefined),
        messages: [...prepared, { role: 'user', content: synthesisPrompt }],
        temperature: 0.2,
        maxTokens
      }, { retries: 2 });
      return { ...result, agents: successful.map(x => ({ provider: x.provider, model: x.model })), agentCount: successful.length };
    } catch (error) { lastError = error; }
  }
  throw lastError || new Error('Nenhum provider conseguiu sintetizar a resposta.');
}

export async function chat({ providerId, model, mode = 'normal', messages, temperature = 0.35, maxTokens = 4096, selectedProviders = [], profile = 'coding' }) {
  if (!Array.isArray(messages) || !messages.length) { const error = new Error('A conversa está vazia.'); error.status = 400; throw error; }
  if (!messages.some(m => m && m.role === 'user' && String(m.content || '').trim())) { const error = new Error('A conversa precisa conter uma mensagem do usuário.'); error.status = 400; throw error; }
  const prepared = compactMessages(withSystem(messages, { coding: profile !== 'general', profile }), Number(process.env.MAX_CONTEXT_CHARS || 90000));
  const latestUser = [...messages].reverse().find(m => m.role === 'user')?.content || '';
  const primary = getProvider(providerId || process.env.DEFAULT_PROVIDER || 'nvidia');
  if (!primary.configured) {
    const error = new Error(`Provider ${primary.id} não está configurado. Configure ${primary.envKey} no .env.`);
    error.status = 400;
    throw error;
  }

  if (mode === 'multi-agent') {
    const pool = sanitizeAgents(selectedProviders);
    const agents = pool.length ? pool.slice(0, Number(process.env.MAX_MULTI_AGENTS || 5)) : defaultPool().slice(0, 4);
    if (!agents.length) throw new Error('Nenhum provider configurado para o modo multi-agente.');
    return { ...(await runMultiAgent({ providers: agents, prepared, latestUser, model, temperature, maxTokens })), mode };
  }

  if (mode === 'normal') {
    const result = await callProvider(primary, { model: resolveModel(primary, model), messages: prepared, temperature, maxTokens });
    return { ...result, mode, fallback: false };
  }

  const ordered = rankProviders(
    [primary, ...eligibleProviders({ freeOnly: false }).filter(p => p.id !== primary.id)],
    { primaryId: primary.id, preferFree: true }
  );
  const errors = [];
  const retries = Number(process.env.MAX_RETRIES_PER_PROVIDER || 2);

  for (const provider of ordered) {
    const effectiveModel = resolveModel(provider, provider.id === primary.id ? model : undefined);
    try {
      const result = await callWithRetry(provider, { model: effectiveModel, messages: prepared, temperature, maxTokens }, { retries });
      return { ...result, mode, fallback: provider.id !== primary.id, attemptedProviders: errors.map(e => e.provider).concat(provider.id) };
    } catch (error) {
      errors.push({ provider: provider.id, status: error?.status || 0, message: error?.message || 'erro' });
      if (!shouldFallback(error)) throw error;
    }
  }
  const err = new Error(`Nenhum provider conseguiu concluir a solicitação. ${errors.map(e => `${e.provider}: ${e.status || ''} ${e.message}`).join(' | ')}`);
  err.status = 503;
  throw err;
}

export function getCircuitState() {
  return Object.fromEntries([...breaker.entries()].map(([id, state]) => [id, { ...state, open: state.openUntil > now() }]));
}
