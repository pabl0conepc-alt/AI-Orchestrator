function readJsonStorage(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
  catch { localStorage.removeItem(key); return fallback; }
}

const state = {
  conversations: readJsonStorage('ai-orch-conversations', []),
  currentId: null,
  providers: [],
  codeMode: true,
  selectedAgents: readJsonStorage('ai-orch-agents', [])
};

const els = {
  chat: document.querySelector('#chat'), input: document.querySelector('#input'), composer: document.querySelector('#composer'),
  conversationList: document.querySelector('#conversationList'), providerSelect: document.querySelector('#providerSelect'),
  modeSelect: document.querySelector('#modeSelect'), modelInput: document.querySelector('#modelInput'), statusDot: document.querySelector('#statusDot'),
  statusText: document.querySelector('#statusText'), providerInfo: document.querySelector('#providerInfo'), modeHint: document.querySelector('#modeHint'),
  settingsDialog: document.querySelector('#settingsDialog'), providerGrid: document.querySelector('#providerGrid'), toolsDialog: document.querySelector('#toolsDialog'),
  toolsSummary: document.querySelector('#toolsSummary'), toolsOutput: document.querySelector('#toolsOutput'), agentsDialog: document.querySelector('#agentsDialog'),
  agentChoices: document.querySelector('#agentChoices'), agentCount: document.querySelector('#agentCount')
};

function save(){ localStorage.setItem('ai-orch-conversations', JSON.stringify(state.conversations)); }
function current(){ return state.conversations.find(c=>c.id===state.currentId); }
function newConversation(){ const c={id:crypto.randomUUID(),title:'Nova conversa',messages:[]}; state.conversations.unshift(c); state.currentId=c.id; save(); render(); }
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function formatText(text){
  const escaped=escapeHtml(text);
  const parts=escaped.split(/```([\w.+-]*)\n([\s\S]*?)```/g);
  let out='';
  for(let i=0;i<parts.length;i+=3){
    out += (parts[i]||'').replace(/`([^`]+)`/g,'<code class="inline-code">$1</code>').replace(/\n/g,'<br>');
    if(parts[i+2]!==undefined) out += `<code class="code-block" data-lang="${escapeHtml(parts[i+1]||'')}">${parts[i+2]}</code>`;
  }
  return out;
}
function render(){
  els.conversationList.innerHTML='';
  for(const c of state.conversations){const b=document.createElement('div');b.className='conversation'+(c.id===state.currentId?' active':'');b.textContent=c.title;b.onclick=()=>{state.currentId=c.id;render()};els.conversationList.appendChild(b)}
  const c=current();
  if(!c){els.chat.innerHTML='<div class="empty">Crie uma conversa e conecte um provider.</div>';return}
  els.chat.innerHTML='';
  for(const m of c.messages){
    const wrap=document.createElement('div');wrap.className='msg '+m.role;
    wrap.innerHTML=`<div class="avatar">${m.role==='user'?'YOU':'AI'}</div><div><div class="bubble">${formatText(m.content)}</div><div class="meta">${escapeHtml(m.meta||'')}</div></div>`;
    els.chat.appendChild(wrap);
  }
  els.chat.scrollTop=els.chat.scrollHeight;
}

async function loadProviders(){
  try{
    const r=await fetch('/api/providers'); const p=await r.json(); state.providers=p;
    const configured=p.filter(x=>x.configured);
    els.providerSelect.innerHTML=configured.map(x=>`<option value="${x.id}">${escapeHtml(x.name)}</option>`).join('');
    const saved=localStorage.getItem('ai-orch-provider');
    if(saved && configured.some(x=>x.id===saved)) els.providerSelect.value=saved;
    els.statusDot.classList.add('ok'); els.statusText.textContent=`online • ${configured.length} providers`;
    updateProviderInfo(); renderSettings(); renderAgentChoices();
  }catch(e){els.statusText.textContent='offline';els.statusDot.classList.remove('ok');}
}
function updateProviderInfo(){const p=state.providers.find(x=>x.id===els.providerSelect.value);els.providerInfo.textContent=p?`${p.name} • padrão: ${p.defaultModel} • ${p.freePool?'pool gratuito':'pool pago/manual'}`:'';}
function renderSettings(){
  els.providerGrid.innerHTML=state.providers.map(p=>`<div class="provider-card"><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml(p.id)}</small><div><span class="pill ${p.configured?'ok':'bad'}">${p.configured?'configurado':'sem chave'}</span><span class="pill">${escapeHtml(p.transport)}</span><span class="pill blue">prioridade ${p.priority}</span></div><small>modelo: ${escapeHtml(p.defaultModel)}</small><div>${Object.entries(p.capabilities||{}).filter(([,v])=>v).map(([k])=>`<span class="pill">${escapeHtml(k)}</span>`).join('')}</div></div>`).join('');
}
function renderAgentChoices(){
  const configured=state.providers.filter(p=>p.configured);
  els.agentChoices.innerHTML=configured.map(p=>`<label class="agent-option"><input type="checkbox" value="${p.id}" ${state.selectedAgents.includes(p.id)?'checked':''}><span><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml(p.defaultModel)}</small></span></label>`).join('');
  updateAgentCount();
}
function updateAgentCount(){els.agentCount.textContent=`${els.agentChoices.querySelectorAll('input:checked').length} selecionados`;}
async function showDiagnostics(){
  els.toolsDialog.showModal(); els.toolsSummary.textContent='Carregando diagnóstico…';
  try{const r=await fetch('/api/dev-tools');const d=await r.json();const installed=Object.entries(d.tools||{}).filter(([,v])=>v.installed).map(([k,v])=>`${k}: ${v.version}`).join('\n')||'Nenhuma ferramenta detectada';els.toolsSummary.textContent=`Ambiente: ${d.platform}\nProjeto: ${d.cwd}\n\nFerramentas:\n${installed}\n\nScripts npm: ${Object.keys(d.packageScripts||{}).join(', ')||'nenhum'}`;}catch(e){els.toolsSummary.textContent=`Erro: ${e.message}`}
}

els.composer.addEventListener('submit', async e=>{
  e.preventDefault(); const text=els.input.value.trim(); if(!text)return; if(!current())newConversation();
  const c=current(); c.messages.push({role:'user',content:text}); if(c.title==='Nova conversa')c.title=text.slice(0,42); save(); els.input.value=''; render();
  const thinking={role:'assistant',content:'Pensando…',meta:'orquestrador'}; c.messages.push(thinking); render();
  try{
    const payload={providerId:els.providerSelect.value,model:els.modelInput.value.trim()||undefined,mode:els.modeSelect.value,messages:c.messages.filter(m=>m!==thinking),temperature:els.modeSelect.value==='multi-agent'?0.25:0.35,maxTokens:4096,selectedProviders:state.selectedAgents,profile:state.codeMode?'coding':'general'};
    const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); const data=await r.json();
    c.messages.pop(); if(!r.ok) throw new Error(data.error||'Falha desconhecida');
    const agentMeta=data.agentCount?` • ${data.agentCount} agentes`:'';
    c.messages.push({role:'assistant',content:data.text,meta:`${data.provider} • ${data.model}${data.fallback?' • fallback':''}${agentMeta}`}); save(); render();
  }catch(err){c.messages.pop();c.messages.push({role:'assistant',content:`Erro: ${err.message}`,meta:'falha do orquestrador'});save();render();}
});

document.querySelector('#newChat').onclick=()=>newConversation();
document.querySelector('#clearBtn').onclick=()=>{const c=current();if(c){c.messages=[];save();render()}};
document.querySelector('#settingsBtn').onclick=()=>els.settingsDialog.showModal();
document.querySelector('#toolsBtn').onclick=showDiagnostics;
document.querySelector('#closeTools').onclick=()=>els.toolsDialog.close();
document.querySelector('#codeMode').onclick=e=>{state.codeMode=!state.codeMode;e.currentTarget.classList.toggle('active',state.codeMode);els.modeHint.textContent=state.codeMode?'CODE ativo':'GERAL ativo'};
document.querySelector('#agentBtn').onclick=()=>{renderAgentChoices();els.agentsDialog.showModal()};
document.querySelector('#saveAgents').onclick=()=>{state.selectedAgents=[...els.agentChoices.querySelectorAll('input:checked')].map(x=>x.value);localStorage.setItem('ai-orch-agents',JSON.stringify(state.selectedAgents));};
els.agentChoices.addEventListener('change',updateAgentCount);
els.providerSelect.addEventListener('change',()=>{localStorage.setItem('ai-orch-provider',els.providerSelect.value);updateProviderInfo()});
els.input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();els.composer.requestSubmit()}});
document.querySelector('#healthBtn').onclick=showDiagnostics;
document.querySelectorAll('[data-run-tool]').forEach(btn=>btn.onclick=async()=>{const tool=btn.dataset.runTool;els.toolsOutput.textContent=`Executando ${tool}…`;try{const r=await fetch('/api/dev-tools/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tool})});const d=await r.json();els.toolsOutput.textContent=`${d.ok?'OK':'FALHOU'}\n\n${d.stdout||''}${d.stderr?'\n[stderr]\n'+d.stderr:''}`}catch(e){els.toolsOutput.textContent=e.message}});

if(!state.conversations.length) newConversation(); else {state.currentId=state.conversations[0].id;render();}
loadProviders();
