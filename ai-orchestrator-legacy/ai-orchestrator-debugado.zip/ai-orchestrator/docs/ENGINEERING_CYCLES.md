# Five engineering passes

## Pass 1 — Understand + plan
Reviewed the existing architecture and identified the provider registry, transports, orchestrator, UI, and environment loading as the core boundaries.

Improvements: provider metadata, priorities, capabilities, explicit routing policy, model resolution.

Review checks: invalid providers, missing keys, model mismatch, free/premium pool separation.

## Pass 2 — Execute routing hardening
Added retry/backoff, circuit breaker, error classification, provider ranking, context compaction and provider-specific default models during fallback.

Review checks: 400 model errors can fallback; ordinary validation errors do not blindly fallback; repeated failures temporarily pause a provider.

## Pass 3 — Multi-agent + coding intelligence
Split multi-agent work into architect, implementer, reviewer, security and tester roles, then synthesize through a coordinator.

Added a stronger coding system prompt covering architecture, debugging, security, testing, Linux/tooling and AI orchestration.

Review checks: parallel agent failures, empty pools, coordinator fallback, context preservation.

## Pass 4 — Developer workbench
Added local diagnostics and allowlisted engineering tools: Git status, Git diff, npm test, npm check, npm build, plus detection of Node, npm, Git, ripgrep and Python.

Review checks: fixed command allowlist, no shell interpolation, timeout and output limits.

## Pass 5 — UX + regression review
Improved the chat interface, provider cards, multi-agent team selection, diagnostics panel, code-aware rendering, status visibility and project scripts.

Regression checks: automated policy tests and local HTTP health/provider/diagnostic endpoints.
