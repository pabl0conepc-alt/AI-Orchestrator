# Debug completo — AI Orchestrator 0.5.1

## Escopo

Auditoria do projeto inteiro, cobrindo backend, frontend, orquestração, providers, scripts, configuração, testes e endpoints HTTP.

## Problemas encontrados e corrigidos

1. **Fallback de modelo estreito** — erros de modelo retornados como HTTP 404 agora podem disparar fallback quando a mensagem indica modelo/deployment/endpoint.
2. **Credencial rejeitada** — HTTP 401 agora é considerado elegível para fallback.
3. **Provider primário sem chave** — a API agora retorna HTTP 400 com orientação clara em vez de falhar como erro interno.
4. **`npm build` inexistente** — foi criado um validador de projeto e o script `npm run build` agora verifica arquivos obrigatórios, JSON e sintaxe JavaScript.
5. **`localStorage` corrompido** — o frontend recupera estado inválido em vez de impedir a aplicação de iniciar.
6. **JSON HTTP inválido** — requisições malformadas agora retornam HTTP 400.
7. **Ferramenta de desenvolvimento ausente** — `/api/dev-tools/run` valida a entrada e retorna HTTP 400 quando o nome não é informado.
8. **Retry configurado como zero** — o motor garante pelo menos uma tentativa.

## Validações executadas

- `node --check` em todos os arquivos JavaScript de `src` e `tests`: **OK**
- `npm test`: **10/10 testes passando**
- `npm run build`: **OK**
- `bash -n` nos scripts shell: **OK**
- JSON de `package.json` e `config/providers.json`: **OK**
- Conferência dos IDs HTML usados pelo JavaScript: **28/28 encontrados**
- Servidor real em `127.0.0.1:3000`: **OK**
- `/api/health`: **OK**
- `/api/providers`: **OK**
- `/api/status`: **OK**
- `/api/dev-tools`: **OK**
- página `/`: **OK**
- JSON inválido: **HTTP 400**
- ferramenta ausente: **HTTP 400**
- conversa vazia: **HTTP 400**

## Observação

As chamadas reais a cada API externa não foram forçadas durante o debug para não consumir quota/créditos nem expor credenciais. A camada de transporte foi validada estaticamente e o servidor foi validado em runtime.
