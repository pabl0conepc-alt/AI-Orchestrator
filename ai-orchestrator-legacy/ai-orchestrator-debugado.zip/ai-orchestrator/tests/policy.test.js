import test from 'node:test';
import assert from 'node:assert/strict';
import { shouldFallback, resolveModel, compactMessages, rankProviders } from '../src/orchestrator/policy.js';

test('fallback detects rate limiting', () => assert.equal(shouldFallback({ status: 429 }), true));
test('fallback detects temporary provider errors', () => assert.equal(shouldFallback({ status: 503 }), true));
test('fallback detects model mismatch', () => assert.equal(shouldFallback({ status: 400, message: 'model not found' }), true));
test('ordinary validation errors do not automatically fallback', () => assert.equal(shouldFallback({ status: 400, message: 'invalid request field' }), false));
test('resolveModel uses provider default for empty and auto', () => {
  const p = { id: 'nvidia', defaultModel: 'openai/gpt-oss-20b' };
  assert.equal(resolveModel(p, ''), p.defaultModel);
  assert.equal(resolveModel(p, 'auto'), p.defaultModel);
});
test('resolveModel supports provider-scoped model', () => {
  const p = { id: 'nvidia', defaultModel: 'x' };
  assert.equal(resolveModel(p, 'nvidia:abc'), 'abc');
});
test('compactMessages keeps the latest context', () => {
  const input = Array.from({ length: 30 }, (_, i) => ({ role: 'user', content: `${i}-` + 'x'.repeat(500) }));
  const result = compactMessages(input, 6000);
  assert.ok(result.length < input.length);
  assert.equal(result.at(-1).content.startsWith('29-'), true);
});
test('rankProviders keeps primary first', () => {
  const p = [{ id: 'b', priority: 1 }, { id: 'a', priority: 90 }];
  assert.deepEqual(rankProviders(p, { primaryId: 'a' }).map(x => x.id), ['a', 'b']);
});


test('fallback detects unauthorized provider credentials as failover-worthy', () => {
  assert.equal(shouldFallback({ status: 401, message: 'invalid api key' }), true);
});

test('fallback detects model errors returned as 404', () => {
  assert.equal(shouldFallback({ status: 404, message: 'model not found' }), true);
});
