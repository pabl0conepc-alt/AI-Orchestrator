#!/usr/bin/env bash
set -euo pipefail
printf '== AI Orchestrator Doctor ==\n'
printf 'Node: '; node --version || true
printf 'npm: '; npm --version || true
printf 'Git: '; git --version || true
printf 'ripgrep: '; rg --version | head -n1 || true
printf 'Python: '; python3 --version || true
printf '\nTests:\n'
npm test
printf '\nProvider env keys configured:\n'
if [ -f .env ]; then
  awk -F= '/^[A-Z0-9_]+=/ { if ($2 != "") print $1 "=configured"; else print $1 "=empty" }' .env
else
  echo '.env ausente'
fi
