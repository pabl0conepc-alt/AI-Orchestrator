import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);
const root = process.cwd();
const required = [
  'package.json',
  'config/providers.json',
  'src/server.js',
  'src/orchestrator/engine.js',
  'src/orchestrator/policy.js',
  'src/providers/registry.js',
  'public/index.html',
  'public/app.js'
];

for (const file of required) {
  try { await fs.access(path.join(root, file)); }
  catch { throw new Error(`Arquivo obrigatório ausente: ${file}`); }
}

JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'));
JSON.parse(await fs.readFile(path.join(root, 'config/providers.json'), 'utf8'));

const jsFiles = [];
async function walk(dir) {
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory() && entry.name !== 'node_modules') await walk(full);
    else if (entry.isFile() && full.endsWith('.js')) jsFiles.push(full);
  }
}
await walk(path.join(root, 'src'));
await walk(path.join(root, 'tests'));
for (const file of jsFiles) await execFileAsync(process.execPath, ['--check', file], { cwd: root });
console.log(`Build/validação OK: ${jsFiles.length} arquivos JS verificados.`);
