#!/usr/bin/env bash
set -euo pipefail

command -v node >/dev/null 2>&1 || { echo 'Node.js 20+ é necessário.'; exit 1; }
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 20 ]; then echo "Node.js 20+ é necessário. Encontrado: $(node --version)"; exit 1; fi

if [ ! -f .env ]; then
  cp .env.example .env
  echo 'Criado .env a partir de .env.example. Preencha as chaves antes de usar os providers.'
fi

node --test
printf '\nAI Orchestrator pronto.\n'
printf 'Rode: npm start\n'
printf 'Abra: http://127.0.0.1:3000\n'
printf 'Diagnóstico: botão Ferramentas dentro da interface.\n'
