#!/usr/bin/env bash
set -euo pipefail

PROJECT="${1:-ai-orchestrator}"
mkdir -p "$PROJECT"/{src/providers,src/orchestrator,src/devtools,public,config,prompts,scripts,tests,docs,data}
printf 'Estrutura criada em ./%s\n' "$PROJECT"
printf '%s\n' 'Pastas: src/providers src/orchestrator src/devtools public config prompts scripts tests docs data'
