# AI Orchestrator 0.5.0

Workbench local para conversar com múltiplos provedores de IA como se fossem uma única ferramenta. O foco desta versão é programação: roteamento, fallback, equipes multiagente e diagnóstico do ambiente.

## Modos

- **Normal:** usa o provider selecionado.
- **Fallback automático:** tenta o principal e passa para outros providers configurados quando há limite, timeout, indisponibilidade ou falha específica de modelo.
- **Multi-Agent:** executa providers em paralelo com funções de arquitetura, implementação, revisão, segurança e testes; depois um coordenador sintetiza a resposta.

## Recursos de código

- Prompt de engenharia de software especializado.
- Contexto compacto para conversas longas.
- Seleção de modelo por provider; no fallback, cada provider usa seu modelo padrão quando necessário.
- Retry com backoff.
- Circuit breaker para providers que falham repetidamente.
- Diagnóstico de Node, npm, Git, ripgrep e Python.
- Ações locais allowlisted: Git status, Git diff, npm test, npm check e npm build.
- Histórico local no navegador.
- Seleção visual da equipe multiagente.

## Estrutura

```text
ai-orchestrator/
├── config/providers.json
├── prompts/coding-system.md
├── src/orchestrator/
├── src/providers/
├── src/devtools/
├── public/
├── scripts/
├── tests/
└── docs/
```

## Rodar

```bash
chmod +x scripts/*.sh
./scripts/setup.sh
npm start
```

Abra `http://127.0.0.1:3000`.

## Verificar

```bash
npm test
./scripts/doctor.sh
```

## Chaves

As credenciais são carregadas do `.env` e nunca devem entrar no Git. O `.env.example` contém somente nomes de variáveis.

## Observações sobre providers

Endpoints e capacidades são dados no `config/providers.json`. APIs compatíveis com OpenAI usam o adapter `openai-chat`; Gemini usa seu adapter específico; OpenCode usa o adapter de Responses configurado para o projeto.

## Engenharia em cinco passes

Consulte `docs/ENGINEERING_CYCLES.md` para o histórico das cinco rodadas de melhoria e revisão aplicadas nesta versão.
